<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <title>Restaurant</title>
</head>

<body>
    <div class="container mt-5">
        <h1 class="text-danger">Welcome to my top 5 Restaurant</h1>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col"></th>
                    <th scope="col">Name</th>
                    <th scope="col">Location</th>
                    <th scope="col">Website</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row"><img
                            src="https://lh5.googleusercontent.com/p/AF1QipP6Wx2K16aaHw02P9eN7EUwInms5CDwVw6Uttoa=w114-h114-n-k-no"
                            alt=""></th>
                    <td>Ilustrado Restaurant</td>
                    <td>Quezon City, Metro manila</td>
                    <td><a href="#">Ilustrado</a></td>
                </tr>
                <tr>
                    <th scope="row"><img
                            src="https://lh5.googleusercontent.com/p/AF1QipO1OLwuPQc9SC9RLm6tI15-Y2v2u1CQLa0TYCaN=w114-h114-n-k-no"
                            alt=""></th>
                    <td>Sala Restaurant</td>
                    <td>Quezon City, Metro manila</td>
                    <td><a href="#">Sala</a></td>
                </tr>
                <tr>
                    <th scope="row"><img
                            src="https://lh5.googleusercontent.com/p/AF1QipNziYKthFoLa787ak7sdtwmoIwLCh2jZRYxXohf=w114-h114-n-k-no"
                            alt=""></th>
                    <td>Ninyo Fusion Cuisine</td>
                    <td>Quezon City, Metro manila</td>
                    <td><a href="">Ninyo Fusion Cuisine</a></td>
                </tr>
                <tr>
                    <th scope="row"><img
                            src="https://lh5.googleusercontent.com/p/AF1QipNziYKthFoLa787ak7sdtwmoIwLCh2jZRYxXohf=w114-h114-n-k-no"
                            alt=""></th>
                    <td>Ninyo Fusion Cuisine</td>
                    <td>Quezon City, Metro manila</td>
                    <td><a href="">Ninyo Fusion Cuisine</a></td>
                </tr>
                <tr>
                    <th scope="row"><img
                            src="https://lh5.googleusercontent.com/p/AF1QipNziYKthFoLa787ak7sdtwmoIwLCh2jZRYxXohf=w114-h114-n-k-no"
                            alt=""></th>
                    <td>Ninyo Fusion Cuisine</td>
                    <td>Quezon City, Metro manila</td>
                    <td><a href="">Ninyo Fusion Cuisine</a></td>
                </tr>
            </tbody>
        </table>
    </div>

</body>

</html>
<?php /**PATH C:\Users\ismae\OneDrive\Desktop\Laravel\Laravel-project-1\restaurant\resources\views/index.blade.php ENDPATH**/ ?>