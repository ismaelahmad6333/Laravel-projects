<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <title>Restaurant</title>
</head>


<style>
    a {
        color: aliceblue;
        list-style: none;
        text-decoration: none
    }
</style>

<body>
    <h1 class="text-danger">SHOPOOO</h1>

    <div class="container mt-5 d-flex gap-5 col-md-18">

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card d-flex flex-column" style="width: 20rem;">
                <img class="card-img-top" src="<?php echo e($product->imageUrl); ?>" alt="Card image cap">
                <div class="card-body ">
                    <a href="/products/<?php echo e($product->id); ?>" class="text-primary">
                        <h6 class="card-title mb-2"> <?php echo e($product->name); ?></h6>
                    </a>
                    <h3 class="text-danger">$523<?php echo e($product->discount); ?></h3>
                    <p class="text-danger">Off: <?php echo e($product->discount); ?></p>
                    <p class="text-secondary"><?php echo e($product->location); ?></p>
                    <span>⭐⭐⭐⭐( <?php echo e($product->sold); ?>)</span>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</body>

</html>
<?php /**PATH C:\Users\ismae\OneDrive\Desktop\Laravel\Laravel-project-1\restaurant\resources\views/products/index.blade.php ENDPATH**/ ?>